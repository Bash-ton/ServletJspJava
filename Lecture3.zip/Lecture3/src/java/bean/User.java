package bean;

/**
 * can now handle password, email, nickname
 * 
 */
public class User{
    private String nickname;
    private String email;
    private String password;
    
    public User(){}
    
    public void setNickname(String s){
        this.nickname = s;
    }
    
    public void setEmail(String s){
        this.email = s;
    }
    
    public void setPassword(String s){
        this.password = s;
    }
    
    public String getNickname(){
        return nickname;
    }
    
    public String getEmail(){
        return email;
    }
    
    public String getPassword(){
        return password;
    }
}