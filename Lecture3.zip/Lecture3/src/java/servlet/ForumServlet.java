package servlet;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import org.json.simple.parser.ParseException;

public class ForumServlet extends HttpServlet {

    public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException, ServletException{
        
        //get this session and check if it has a user bean/object already
        HttpSession session = request.getSession(true);
        bean.User user = (bean.User)session.getAttribute("user");
           
        //if new user create a user objec/bean for this session
        //render login jsp page
        if(session.isNew()){
            session.setAttribute("user", new bean.User());
            try{
            session.setAttribute("solution", new bean.Solution());
            }
            catch(ParseException e){}
            //render part here
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
            rd.forward(request, response); 
        }
        //if session/client already has nickname, password & email render the quiz
        if((user.getNickname() != null) && (user.getEmail()!= null) && (user.getPassword() != null)){
            //render part here
            RequestDispatcher rd = request.getRequestDispatcher("quiz.jsp");
            rd.forward(request, response);
        
        //else if bean/model/database does not have user info stored but url has just recieved info
        //update bean/model/database and render the quiz.
        }else if(request.getParameter("email")!=null){
            //update bean/model/database part here
            bean.User u = (bean.User)session.getAttribute("user");
            u.setNickname(request.getParameter("nickname"));
            u.setEmail(request.getParameter("email"));
            u.setPassword(request.getParameter("password"));
            //render part here
            RequestDispatcher rd = request.getRequestDispatcher("quiz.jsp");
            rd.forward(request, response);
          
        //else if not user info is provided (not in url or bean/model/database)
        //render the default login page
        }else{
            //render part here
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
            rd.forward(request, response);
        } 
         if(request.getParameter("question1")!=null){
              bean.Solution s = (bean.Solution)session.getAttribute("solution");
            s.setQuestion1(request.getParameter("question1")); 
            s.setQuestion2(request.getParameter("question2")); 
             s.setQuestion3(request.getParameter("question3")); 
              s.setQuestion4(request.getParameter("question4")); 
               s.setQuestion5(request.getParameter("question5"));

               
            RequestDispatcher rd = request.getRequestDispatcher("result.jsp");
            rd.forward(request, response);
        
                  }
      
    }
}