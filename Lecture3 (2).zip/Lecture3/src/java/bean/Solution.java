/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.IOException;
import org.json.simple.parser.ParseException;

/**
 *
 * @author moham
 */
public class Solution implements java.io.Serializable {
    
    private String Q1;
    private String Q2;
    private String Q3;
    private String Q4;
    private String Q5;
     QuizBean quizbean = new QuizBean();
    
    public Solution() throws IOException,ParseException{
       
    }
    
    public void setQuestion1(String question){
    this.Q1=question;
    }
    public void setQuestion2(String question){
    this.Q2=question;
     System.out.println("++++++++++++++++");
   
    System.out.println(question);
    }
    public void setQuestion3(String question){
    this.Q3=question;
    }
    public void setQuestion4(String question){
    this.Q4=question;
    }
    public void setQuestion5(String question){
    this.Q5=question;
    }
    public String getQuistion1(){
        return Q1;
    }
    
    public int getQuizPoint(){
        int result=0;
        if((Q1).equals(quizbean.getAnswer("Q1"))){
            
            result++;
        }
        if((Q2).equals(quizbean.getAnswer("Q2"))){
            result++;
        }
     
        if((Q3).equals(quizbean.getAnswer("Q3"))){
            result++;
        }
     
        if((Q4).equals(quizbean.getAnswer("Q4"))){
            result++;
        }
     
        if((Q5).equals(quizbean.getAnswer("Q5"))){
            result++;
        } 
  
        return result;
    }
    
    
    
}
