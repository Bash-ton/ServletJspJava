
package bean;
import database.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class QuizBean implements java.io.Serializable{
    
    private String[] answers = new String[5];
    private String[][] questionsSuggestions = new String[20][20];  
    private JSONObject jsonobj;
    
 
    public QuizBean() throws IOException, ParseException{
        JSONParser parser = new JSONParser();        
        Object obj = parser.parse(new FileReader("C:\\Users\\moham\\Desktop\\Lecture3\\myJSON.json"));
        
        this.jsonobj = (JSONObject) obj;
   
    
        //TEST
        // System.out.println(getQuestion("Q1"));
        //System.out.println(getQuestionAlternative("Q3", "alt1"));
        //System.out.println(getAnswer("Q1"));
        
        
    }
  
    //skicka liknande Q1, Q2 osv
    public String getQuestion(String question){
        return (String) jsonobj.get(question);
    }
    //skicka liknande Q1, Q2 osv
    public String getAnswer(String answer){
        return (String) jsonobj.get(answer + "Answer");
    }
    //skicka vilken question och alternativ ex(Q1, alt2)
    public String getQuestionAlternative(String q, String a){
        a = a.replaceAll("[^\\d.]", "");
        System.out.println(a);
        String[] test = getSuggestions(q);
        String suggest = null;
        for(int i=0; i<test.length;i++){
            if(Integer.parseInt(a)==(i+1)){
                suggest = test[i];
               
            }
            
        }
        return suggest;
    }
    //skicka liknande Q1, Q2 osv
    private String[] getSuggestions(String suggestions){
        
        JSONArray suggestArr = (JSONArray) jsonobj.get(suggestions + "Suggestions");
        Iterator<Object> iterator = suggestArr.iterator();
        int n = suggestArr.size();   
        String[] suggestStringArray = new String[n]; 
        int i = 0;
        while(iterator.hasNext()){
            suggestStringArray[i] = (String)iterator.next();
           i++;
        }
        return suggestStringArray;
        
    }
   
    //for testing
    //remove later
    public static void main(String[] args) throws IOException, ParseException{
        new QuizBean();     
        
    }
    
  
}




      

